/*
File: dp.js
Student Name: Manvibolreach Ouk
Student ID: 301224112
Date: October 31, 2022
*/

module.exports = {
  URI: "mongodb+srv://COMP229-F2022-Midterm-301224112:ERsPJ0t5Iwt9uyuz@cluster0.qpmlaui.mongodb.net/business?retryWrites=true&w=majority",
};
